<?php
    session_start();
    require 'db.php';

    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $number = $_POST['number'];
    $password = $_POST['password'];
    $hash_password = password_hash($password, PASSWORD_DEFAULT);
    $conform_password = $_POST['conform_password'];
    $hash_conform_password = password_hash($conform_password, PASSWORD_DEFAULT);
    $select_country = $_POST['select_country'];
    $birthday = $_POST['birthday'];
    $gender = $_POST['gender'];

    $flag = false;

    if(!$first_name){
        $flag = true;
        $_SESSION['first_name'] = 'Enter First Name !';
    }
    if(!$last_name){
        $flag = true;
        $_SESSION['last_name'] = 'Enter Last Name !';
    }
    if(!$email){
        $flag = true;
        $_SESSION['email'] = 'Enter Email Address !';
    }else{
        if(!filter_var($email, FILTER_VALIDATE_EMAIL)){
            $flag = true;
            $_SESSION['email'] = "Enter Valid Email('@' missing)!";
        }
    }
    if(!$number){
        $flag = true;
        $_SESSION['number'] = 'Enter Phone Number !';
    }
    if(!$password){
        $flag = true;
        $_SESSION['password'] = 'Enter Password !';
    }else{
        $upper = preg_match('@[A-Z]@', $password);
        $lower = preg_match('@[a-z]@', $password);
        $spacial = preg_match('@[!,#,%,$,&,*,?,<,>,/]@', $password);
        if(!$upper){
            $flag = true;
            $_SESSION['password'] = 'Upper Case Letter!';
        }
        if(!$lower){
            $flag = true;
            $_SESSION['password'] = 'Lower Case Letter!';
        }
        if(!$spacial){
            $flag = true;
            $_SESSION['password'] = 'Spacial Carrecter!';
        }
        if(strlen($password) < 8){
            $flag = true;
            $_SESSION['password'] = 'Minimum 8 letters!';
        }

    }

    if(!$conform_password){
        $flag = true;
        $_SESSION['conform_password'] = 'Enter Conform Password !';
    }else{
        $upper = preg_match('@[A-Z]@', $conform_password);
        $lower = preg_match('@[a-z]@', $conform_password);
        $spacial = preg_match('@[!,#,%,$,&,*,?,<,>,/]@', $conform_password);
        if(!$upper){
            $flag = true;
            $_SESSION['conform_password'] = 'Upper Case Letter!';
        }
        if(!$lower){
            $flag = true;
            $_SESSION['conform_password'] = 'Lower Case Letter!';
        }
        if(!$spacial){
            $flag = true;
            $_SESSION['conform_password'] = 'Spacial Carrecter!';
        }
        if(strlen($conform_password) < 8){
            $flag = true;
            $_SESSION['conform_password'] = 'Minimum 8 letters!';
        }

    }

    if(!$select_country){
        $flag = true;
        $_SESSION['select_country'] = 'Select Your Country !';
    }
    if(!$birthday){
        $flag = true;
        $_SESSION['birthday'] = 'Select Your Birthday !';
    }
    if(!$gender){
        $flag = true;
        $_SESSION['gender'] = 'Select Your Gender !';
    }
    


    if($flag){
        header('location:registration.php');
    }else{

        $insert = "INSERT INTO users(first_name, last_name, email, phone_number, password, conform_password, your_country, date_of_birth, gender) VALUE ('$first_name', '$last_name', '$email', '$number', '$hash_password', '$hash_conform_password', '$select_country', '$birthday', '$gender')";
        mysqli_query($db_connect, $insert);

        $_SESSION['success'] = 'User Registered Success!';

        header('location:registration.php');

    }

  


?>