<?php session_start(); ?>

<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css"/>
    <style>
        .pass_show{
            position: relative;
        }
        .pass_show i {
            position: absolute;
            top: 35px;
            right: 30px;
            font-size: 15px;
            color: #727272;
            cursor: pointer;
        }
        .pass_show2{
            position: relative;
        }
        .pass_show2 i {
            position: absolute;
            top: 35px;
            right: 30px;
            font-size: 15px;
            color: #727272;
            cursor: pointer;
        }
    </style>
  </head>
  <body class="bg-black">
  
    <div class="container">
       <div class="row">
        <div class="col-6 m-auto mt-5">
            <div class="card">
                <div class="card-header bg-primary text-center">
                    <h4 class="text-white">Registration Form</h4>
                </div>
                <div class="card-body bg-warning">

                    <?php if(isset($_SESSION['success'])){ ?>
                        <div class="alert alert-success"><?= $_SESSION['success'] ?></div>
                    <?php } unset($_SESSION['success'])?>

                    <form action="registration_post.php" method="POST">
                        <div class="mb-3">
                            <div class="row">
                                <div class="col-6">
                                    <label for="first_name">First Name</label>
                                    <input type="text" id="first_name" name="first_name" class="form-control" placeholder="Enter First Name" style="border-color: <?= (isset($_SESSION['first_name']))? 'red':'' ?>">

                                    <?php if(isset($_SESSION['first_name'])){ ?>
                                        <strong class="text-danger"><?= $_SESSION['first_name'] ?></strong>
                                    <?php }unset($_SESSION['first_name']) ?>

                                </div>
                                <div class="col-6">
                                    <label for="last_name">Last Name</label>
                                    <input type="text" id="last_name" name="last_name" class="form-control" placeholder="Enter Last Name" style="border-color: <?= (isset($_SESSION['last_name']))? 'red':'' ?>">

                                    <?php if(isset($_SESSION['last_name'])){ ?>
                                        <strong class="text-danger"><?= $_SESSION['last_name'] ?></strong>
                                    <?php }unset($_SESSION['last_name']) ?>

                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <div class="row">
                                <div class="col-6">
                                    <label for="email">Email</label>
                                    <input type="text" id="email" name="email" class="form-control" placeholder="Enter Email Address" style="border-color: <?= (isset($_SESSION['email']))? 'red':'' ?>">

                                    <?php if(isset($_SESSION['email'])){ ?>
                                        <strong class="text-danger"><?= $_SESSION['email'] ?></strong>
                                    <?php }unset($_SESSION['email']) ?>

                                </div>
                                <div class="col-6">
                                    <label for="number">Phone Number</label>
                                    <input type="number" id="number" name="number" class="form-control" placeholder="Phone Number" style="border-color: <?= (isset($_SESSION['number']))? 'red':'' ?>">

                                    <?php if(isset($_SESSION['number'])){ ?>
                                        <strong class="text-danger"><?= $_SESSION['number'] ?></strong>
                                    <?php }unset($_SESSION['number']) ?>

                                </div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <div class="row">
                                <div class="col-6 pass_show">
                                    <label for="password">Password</label>
                                    <input type="password" id="password" name="password" class="form-control" placeholder="Password" style="border-color: <?= (isset($_SESSION['password']))? 'red':'' ?>">
                                    <i id="password_show" class="fa-regular fa-eye eye1"></i>

                                    <?php if(isset($_SESSION["password"])){ ?>
                                        <strong class="text-danger"><?= $_SESSION["password"]; ?></strong>
                                    <?php } unset($_SESSION["password"]) ?>

                                </div>
                                <div class="col-6 pass_show2">
                                    <label for="conform_password">Conform Password</label>
                                    <input type="password" id="conform_password" name="conform_password" class="form-control" placeholder="Conform Password" style="border-color: <?= (isset($_SESSION['conform_password']))? 'red':'' ?>">
                                    <i id="password_show2" class="fa-regular fa-eye eye2"></i>

                                    <?php if(isset($_SESSION["conform_password"])){ ?>
                                        <strong class="text-danger"><?= $_SESSION["conform_password"]; ?></strong>
                                    <?php } unset($_SESSION["conform_password"]) ?>

                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <div class="row">
                                <div class="col-6">
                                    <label for="gender1">Your Country</label>
                                    <select class="form-select" name="select_country" style="border-color: <?= (isset($_SESSION['select_country']))? 'red':'' ?>">
                                        <option value="">Select Your Country</option>
                                        <option value="bangladesh">Bangladesh</option>
                                        <option value="india">India</option>
                                        <option value="nepal">Nepal</option>
                                        <option value="pakistan">Pakistan</option>
                                        <option value="srilanka">Srilanka</option>
                                    </select>

                                    <?php if(isset($_SESSION["select_country"])){ ?>
                                        <strong class="text-danger"><?= $_SESSION["select_country"]; ?></strong>
                                    <?php } unset($_SESSION["select_country"]) ?>

                                </div>
                                <div class="col-6">
                                    <label for="date">Date Of Birth</label>
                                    <input type="date" id="date" class="form-control" name="birthday" style="border-color: <?= (isset($_SESSION['birthday']))? 'red':'' ?>">

                                    <?php if(isset($_SESSION["birthday"])){ ?>
                                        <strong class="text-danger"><?= $_SESSION["birthday"]; ?></strong>
                                    <?php } unset($_SESSION["birthday"]) ?>

                                </div>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Are You?</label>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="gender" value="Male" id="gender1">
                                <label class="form-check-label" for="gender1">Male</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="gender" value="Female" id="gender2">
                                <label class="form-check-label" for="gender2">Female</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="radio" name="gender" value="others" id="gender3">
                                <label class="form-check-label" for="gender3">Others</label>
                            </div>

                            <?php if(isset($_SESSION["gender"])){ ?>
                                <strong class="text-danger"><?= $_SESSION["gender"]; ?></strong>
                            <?php } unset($_SESSION["gender"]) ?>

                        </div>
                        <div class="mb-3">
                            <button type="submit" class="btn btn-primary btn-lg text-white">Register</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
       </div> 
    </div>
    

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script>
        $('#password_show').click(function(){
            var pass = document.getElementById('password');

            if(pass.type == 'password'){
                pass.type = 'text';
            }else{
                pass.type = 'password';
            }
        })
    </script>
    <script>
        $('#password_show2').click(function(){
            var pass = document.getElementById('conform_password');

            if(pass.type == 'password'){
                pass.type = 'text';
            }else{
                pass.type = 'password';
            }
        })
    </script>
  </body>
</html>