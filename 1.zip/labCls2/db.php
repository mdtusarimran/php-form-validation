<?php

    $hostname = "localhost";
    $hostuser = "root";
    $hostpassword = "";
    $database_name = "lab2";

    $db_connect = mysqli_connect($hostname, $hostuser, $hostpassword, $database_name);

?>